package com.voicetype.keyboard

/** Dependency-free smoke tests; run with the Kotlin compiler. */
object PackageIntegritySelfTest {
    @JvmStatic
    fun main(args: Array<String>) {
        val sample = "abc".toByteArray(Charsets.UTF_8)
        val knownSha256 = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        check(PackageIntegrity.sha256(sample) == knownSha256) { "SHA-256 known vector failed" }
        check(PackageIntegrity.verify(sample, knownSha256)) { "Valid package checksum rejected" }
        check(!PackageIntegrity.verify(sample, "0".repeat(64))) { "Checksum mismatch accepted" }
        check(!PackageIntegrity.verify(sample, "not-a-hash")) { "Malformed checksum accepted" }
        check(!PackageIntegrity.verify(byteArrayOf(), knownSha256)) { "Empty package accepted" }
        check(!PackageIntegrity.verify(ByteArray(PackageIntegrity.MAX_PACKAGE_BYTES + 1), knownSha256)) { "Oversized package accepted" }
        check(PackageIntegrity.isValidPackageId("theme.royal-blue")) { "Valid package ID rejected" }
        check(!PackageIntegrity.isValidPackageId("../payload")) { "Path traversal package ID accepted" }
        check(!PackageIntegrity.isValidPackageId("Theme Name")) { "Whitespace package ID accepted" }
        println("PASS: 9 package-integrity checks")
    }
}
