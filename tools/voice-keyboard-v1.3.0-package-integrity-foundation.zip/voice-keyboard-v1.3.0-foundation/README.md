# Voice Keyboard v1.3.0 — Package Integrity Foundation

This is a small, independently tested foundation module for the v1.3.0 Package Manager. It is **not** the complete Android app upgrade and is not integrated into the app yet.

## Included
- SHA-256 calculation and checksum verification
- Rejects empty packages and packages larger than 2 MiB
- Validates package IDs to prevent path-like identifiers
- Dependency-free smoke tests using a published SHA-256 test vector

## Run the checks

```sh
kotlinc src/main/kotlin/com/voicetype/keyboard/PackageIntegrity.kt src/test/kotlin/com/voicetype/keyboard/PackageIntegritySelfTest.kt -include-runtime -d package-integrity-tests.jar
java -jar package-integrity-tests.jar
```

Expected output: `PASS: 9 package-integrity checks`

## Security boundary
Only data packages should be supported (for example theme colors and keyboard layout metadata). Do not load downloaded Kotlin, Java, DEX, JAR, APK, scripts, or other executable content. A valid checksum proves file integrity against the catalog value; it does not prove that a catalog publisher is trustworthy. Catalog transport and publisher authenticity still need to be implemented and reviewed before production use.
