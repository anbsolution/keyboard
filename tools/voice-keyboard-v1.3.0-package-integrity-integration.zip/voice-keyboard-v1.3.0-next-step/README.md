# Voice Keyboard v1.3.0 – Package integrity integration step

This patch places the previously smoke-tested, data-only package integrity helper into the Android app source tree.

## Files
- `app/src/main/java/com/voicetype/keyboard/PackageIntegrity.kt` – SHA-256, size, and package-ID validation.
- `app/src/test/java/com/voicetype/keyboard/PackageIntegritySelfTest.kt` – dependency-free Kotlin smoke test.

## Apply
Copy the `app/` directory into the existing repository, merging directories. Do not replace the repository or change the application ID.

## Verification performed
The helper and smoke test were compiled with the installed Kotlin compiler and executed. Android Gradle build was not run in this patch step.
