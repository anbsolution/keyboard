# KeyboardService.kt theme integration patch

In `buildKeyboard()`, replace the existing `bg`, `keyBg`, and `fg` declarations with:

```kotlin
val customBg = prefs.getString("custom_theme_background", null)
val customKeyBg = prefs.getString("custom_theme_key_background", null)
val customFg = prefs.getString("custom_theme_foreground", null)
val customTheme = theme == "Custom" &&
    !customBg.isNullOrBlank() && !customKeyBg.isNullOrBlank() && !customFg.isNullOrBlank()

val bg = if (customTheme) Color.parseColor(customBg) else when (theme) {
    "Dark" -> Color.rgb(35, 39, 47)
    "Blue" -> Color.rgb(20, 54, 100)
    else -> Color.rgb(232, 237, 246)
}
val keyBg = if (customTheme) Color.parseColor(customKeyBg) else
    if (theme == "Dark") Color.rgb(67, 73, 84) else Color.WHITE
val fg = if (customTheme) Color.parseColor(customFg) else
    if (theme == "Dark") Color.WHITE else Color.rgb(24, 43, 72)
```

This keeps the existing keyboard layout, voice and clipboard behavior unchanged.
```
