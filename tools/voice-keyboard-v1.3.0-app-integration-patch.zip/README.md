# Voice Keyboard v1.3.0 — app integration patch

This patch connects the Feature Store MVP to the launcher activity and registers it in the manifest. It also updates the app version to 1.3.0 (versionCode 6) while preserving applicationId `com.voicetype.keyboard`.

## Included replacement files
- `MainActivity.kt`: adds the Feature Store launcher button.
- `AndroidManifest.xml`: registers `FeatureStoreActivity` as non-exported.
- `app/build.gradle.kts`: versionName 1.3.0, versionCode 6.
- `INTEGRATE_KEYBOARD_SERVICE_THEME.md`: exact minimal change needed in `KeyboardService.kt` to read custom theme colors.

## Required source files
Also copy these from the preceding Feature Store MVP patch into the project:
- `FeaturePackage.kt`
- `FeatureStoreRepository.kt`
- `FeatureStoreActivity.kt`
- `PackageIntegrity.kt`

## Verification status
- ZIP archive integrity and extracted-file equality are verified.
- No Android Gradle build has been run for this patch.
- Apply the KeyboardService theme snippet before treating custom themes as fully integrated.
- Do not install this patch as an APK; it is source code only.
