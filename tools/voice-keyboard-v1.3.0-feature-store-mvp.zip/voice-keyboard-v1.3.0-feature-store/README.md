# Voice Keyboard v1.3.0 — Feature Store MVP

This patch adds a **local-only Feature Store MVP** with five built-in data-only theme packages.

## Included
- Feature Store screen (`FeatureStoreActivity`)
- Included `PackageIntegrity` SHA-256 helper
- Five offline theme packages: Royal Blue, Royal Gold, Mint Light, Graphite, Violet
- SHA-256 verification before installation
- Package ID validation and strict color-value validation
- Local package storage and removal
- Apply an installed theme through `keyboard_prefs`

## Important integration steps
1. Copy the `app/src/main/...` and `app/src/test/...` files into the existing app.
2. Register `FeatureStoreActivity` in `app/src/main/AndroidManifest.xml` as `android:exported="false"`.
3. Add a button in `MainActivity` that opens `FeatureStoreActivity`.
4. Update `KeyboardService` to read the `custom_theme_*` preferences when `theme == "Custom"`.
5. Increment `versionCode` from 5 to 6 and `versionName` from 1.2.0 to 1.3.0 only when the complete app integration is ready.

## Scope limits
- This is an offline MVP, not a remote package downloader.
- It does not contain 50 downloadable themes.
- It does not claim all 22 scheduled-language layouts or translation models are available.
- Download catalog, HTTPS allowlist, package-size limits, checksum manifest signing, update flow and language packs remain later tasks.
- Downloaded packages must remain data-only; do not execute downloaded code.
- Existing app ID stays `com.voicetype.keyboard`.

## Verification
Source-level tests should be run through the project's GitHub Actions workflow after integration. This patch alone is not a complete APK release.
